<?php include("inc/header.php");?>	

<div class="main">
    <div class="content">
		<div class="section group">
			<div class="notFound">
				<h2 style="color:red; text-align:center; line-height: 130px; font-size:70px">Error 404: Page does not exist!<br>Are you sure what you are looking for?</h2>
			</div>
		</div>
	</div>
</div>

<?php include("inc/footer.php");?>